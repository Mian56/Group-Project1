package com.example.groupproject1;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.Objects;

public class Car {
    private ImageView carImageView;
    private double width = 30;
    private double height = 15;

    public Car(double x, double y) {
        // Load the image of the car from your resources folder
        Image carImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/car.png")));
        carImageView = new ImageView(carImage);

        carImageView.setFitWidth(width);
        carImageView.setFitHeight(height);
        setPosition(x, y); 
    }

    public ImageView getCarShape() {
        return carImageView;
    }

    public double getX() {
        return carImageView.getLayoutX();
    }

    public double getY() {
        return carImageView.getLayoutY();
    }

    public void setPosition(double x, double y) {
        carImageView.setLayoutX(x);
        carImageView.setLayoutY(y);
    }

    public void setRotation(double angle) {
        carImageView.setRotate(angle);
    }
}
