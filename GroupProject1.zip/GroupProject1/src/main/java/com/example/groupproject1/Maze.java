package com.example.groupproject1;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Objects;

public class Maze extends Application {
    private Image mazeImage1;
    private Image mazeImage2;
    private Car car;
    private Robot robot;
    private Pane mazePane1;
    private Pane mazePane2;
    private boolean autoMoveEnabled = false;
    private Timeline autoMoveTimeline;

    @Override
    public void start(Stage primaryStage) {
        mazeImage1 = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/maze.png"))); // Maze 1 image
        mazeImage2 = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/maze2.png"))); // Maze 2 image
        car = new Car(35, 260); // Initial position of the car
        robot = new Robot(30,260);


        // Create both maze panes
        mazePane1 = createMazePane(mazeImage1, car);
        mazePane2 = createMazePane(mazeImage2, new Car(-100, -100));

        TabPane tabPane = new TabPane();
        Tab tab1 = new Tab("Maze 1", mazePane1);
        Tab tab2 = new Tab("Maze 2", mazePane2);
        tabPane.getTabs().addAll(tab1, tab2);


        Scene scene = new Scene(tabPane, 609, 430);
        scene.setOnKeyPressed(this::handleKeyPress);
        primaryStage.setTitle("Maze Game");
        primaryStage.setScene(scene);
        primaryStage.show();
        setupAutoMovement();
    }
// goal was to create a button to switch between the robot and the car. I failed to achieve that goal
//    private void switchCarWithRobot(Car car, Robot robot) {
//        // Toggle visibility of the car and the robot
//        if (car.getCarShape().isVisible()) {
//            car.getCarShape().setVisible(false); // Hide the car
//            robot.getRobotShape().setVisible(true); // Show the robot
//        } else {
//            car.getCarShape().setVisible(true); // Show the car
//            robot.getRobotShape().setVisible(false); // Hide the robot
//        }
//    }


    private Pane createMazePane(Image mazeImage, Car car) {
        Canvas canvas = new Canvas(mazeImage.getWidth(), mazeImage.getHeight());
        GraphicsContext gc = canvas.getGraphicsContext2D();
        gc.drawImage(mazeImage, 0, 0);

        Pane pane = new Pane();
        pane.getChildren().addAll(canvas, car.getCarShape());

        Button resetButton = new Button("Reset Car");
        resetButton.setOnAction(e -> {
            car.setPosition(35, 260); // Reset car position
        });
        resetButton.setLayoutX(10);
        resetButton.setLayoutY(10);
        pane.getChildren().add(resetButton);
        return pane;
    }

    private void handleKeyPress(KeyEvent event) {
        KeyCode keyCode = event.getCode();
        switch (keyCode) {
            case W -> moveCar(0, -10); // Move up
            case S -> moveCar(0, 10);  // Move down
            case A -> moveCar(-10, 0); // Move left
            case D -> moveCar(10, 0);  // Move right
            //should move robot but having trouble with key
//            case W -> moveRobot(0, -10); // Move up
//            case S -> moveRobot(0, 10);  // Move down
//            case A -> moveRobot(-10, 0); // Move left
//            case D -> moveRobot(10, 0);  // Move right
            case SPACE -> toggleAutoMove(); // Toggle auto move
        }
    }

    private void moveCar(int dx, int dy) {
        double nextX = car.getX() + dx;
        double nextY = car.getY() + dy;


        if (nextX >= 609 - 20) {
            switchToMaze2();
            return;
        }

        // Check for collisions with blue walls (assuming blue is the color of walls)
        if (isInBounds(nextX, nextY) /*&& !isBlue(pixelReader, nextX, nextY*/){
            car.setPosition(nextX, nextY);
        } else {
            car.setPosition(35, 260); // Reset position
        }
    }

    private boolean isInBounds(double x, double y) {
        return x >= 0 && x < mazeImage1.getWidth() && y >= 0 && y < mazeImage1.getHeight();
    }

    // tried to limit the car's freedom but was unsuccessful
//    private boolean isBlue(PixelReader pixelReader, double x, double y) {
//        Color color = pixelReader.getColor((int) x, (int) y);
//        return color.equals(Color.BLUE); // Check if the pixel color is blue
//    }


    //method not complete
    private void moveRobot(int dx, int dy) {
//        PixelReader pixelReader = getCurrentMaze().getPixelReader();
        double nextX = robot.getX() + dx; // Use robot's position
        double nextY = robot.getY() + dy; // Use robot's position

    }



    private void setupAutoMovement() {
        autoMoveTimeline = new Timeline(new KeyFrame(Duration.millis(200), event -> {
            if (autoMoveEnabled) {
                moveCar(10, 0);
            }
        }));
        autoMoveTimeline.setCycleCount(Timeline.INDEFINITE);
    }

    private void toggleAutoMove() {
        autoMoveEnabled = !autoMoveEnabled; // Toggle auto move
        if (autoMoveEnabled) {
            autoMoveTimeline.play();
        } else {
            autoMoveTimeline.stop();
        }
    }

    //method does not work
    private void switchToMaze2() {
        car.setPosition(-100, -100); // Move car out of view
        mazePane1.getChildren().clear(); // Clear previous maze elements

        mazePane2 = createMazePane(mazeImage2, new Car(-100, -100)); // Create a new pane for Maze 2 without the car
        // Update the tab content for Maze 2
        TabPane tabPane = (TabPane) mazePane1.getParent();
        Tab tab2 = tabPane.getTabs().get(1);
        tab2.setContent(mazePane2); // Update the tab content for Maze 2
    }

    public static void main(String[] args) {
        launch();
    }
}
