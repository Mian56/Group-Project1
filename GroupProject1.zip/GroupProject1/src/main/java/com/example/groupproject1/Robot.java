package com.example.groupproject1;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.Objects;

public class Robot {
    private ImageView robotImageView;
    private double width = 40;  // Set width for the robot
    private double height = 40; // Set height for the robot

    public Robot(double x, double y) {
        // Load the image of the robot from your resources folder
        Image robotImage = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/robot.png")));
        robotImageView = new ImageView(robotImage);

        robotImageView.setFitWidth(width);
        robotImageView.setFitHeight(height);
        setPosition(x, y);
    }

    public ImageView getRobotShape() {
        return robotImageView;
    }

    public double getX() {
        return robotImageView.getLayoutX();
    }

    public double getY() {
        return robotImageView.getLayoutY();
    }

    public void setPosition(double x, double y) {
        robotImageView.setLayoutX(x);
        robotImageView.setLayoutY(y);
    }

    public void setRotation(double angle) {
        robotImageView.setRotate(angle);
    }
}
