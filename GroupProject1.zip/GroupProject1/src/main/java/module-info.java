module com.example.groupproject1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.groupproject1 to javafx.fxml;
    exports com.example.groupproject1;
}